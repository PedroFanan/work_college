package Uninter;

import java.util.List;
import java.util.ArrayList;

public class Principal {

	public static void main(String[] args) {
		
		Menu menu = new Menu();
		menu.exibirMenuPrincipal();
		

	
}

}